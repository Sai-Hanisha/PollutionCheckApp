package com.stackroute.pollutioncheck.UserAuthetincation.exception;

public class UserAlreadyExistException extends Exception {

	public UserAlreadyExistException(String message) {
		super(message);
	}
}
