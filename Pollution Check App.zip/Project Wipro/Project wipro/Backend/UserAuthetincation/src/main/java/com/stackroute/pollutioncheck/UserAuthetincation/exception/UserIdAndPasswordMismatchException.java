package com.stackroute.pollutioncheck.UserAuthetincation.exception;

public class UserIdAndPasswordMismatchException extends Exception{

	public UserIdAndPasswordMismatchException(String message) {
		super(message);
	}
}
