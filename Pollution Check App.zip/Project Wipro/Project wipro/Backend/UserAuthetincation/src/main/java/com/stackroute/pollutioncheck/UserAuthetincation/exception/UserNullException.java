package com.stackroute.pollutioncheck.UserAuthetincation.exception;

public class UserNullException extends Exception {

	public UserNullException(String message) {
		super(message);
	}
}
