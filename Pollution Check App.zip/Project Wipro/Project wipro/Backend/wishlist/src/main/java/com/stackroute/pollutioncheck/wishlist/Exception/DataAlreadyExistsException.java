package com.stackroute.pollutioncheck.wishlist.Exception;

public class DataAlreadyExistsException extends Exception{

	public DataAlreadyExistsException(String message) {
		super(message);
	}
}
