declare module 'parallax-js' {
    export interface parallax {}
    export function Parallax(scene:any, optionns?:object): void;
}