import { Lot } from './lot';

describe('Lot', () => {
  it('should create an instance', () => {
    expect(new Lot()).toBeTruthy();
  });
});
