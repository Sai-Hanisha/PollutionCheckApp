export class Lot {
    lon:number;
    lat:number;
}
